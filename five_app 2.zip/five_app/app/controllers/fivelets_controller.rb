class FiveletsController < ApplicationController
  def new
  	@fivelet = Fivelet.new
  end

  def create
  	@fivelet = Fivelet.new(fivelet_params)
  	if @fivelet.save
  		redirect_to @fivelet
  	else
  		
  	end
  end

  def show
  	@fivelet = Fivelet.find(params[:id])
  end


private
  def fivelet_params
  	params.require(:fivelet).permit(:artist1,:artist2, :artist3, :artist4, :artist5)
  end

end





