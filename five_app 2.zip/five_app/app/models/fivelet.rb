class Fivelet < ApplicationRecord
	validates_presence_of :artist1, :artist2, :artist3, :artist4, :artist5
end
