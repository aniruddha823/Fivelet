Rails.application.routes.draw do
	root 'home#index'
  get 'fivelet/new'
  get 'home/index'
  get 'fivelet/show', to: 'fivelet#create'
  resources :fivelets
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
